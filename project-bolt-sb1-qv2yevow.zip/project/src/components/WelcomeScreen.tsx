import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { Play, Target, Clock, Trophy, Zap, Sword, Shield, Star } from 'lucide-react';

const WelcomeScreen: React.FC = () => {
  const { dispatch } = useGame();
  const [userName, setUserName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('🧙‍♂️');

  const avatarOptions = [
    { emoji: '🧙‍♂️', name: 'Wise Sage' },
    { emoji: '⚔️', name: 'Brave Knight' },
    { emoji: '🏹', name: 'Swift Archer' },
    { emoji: '🛡️', name: 'Noble Guardian' },
    { emoji: '🔮', name: 'Mystic Oracle' },
    { emoji: '🗡️', name: 'Skilled Warrior' },
    { emoji: '🏆', name: 'Champion' },
    { emoji: '⭐', name: 'Hero' },
    { emoji: '💎', name: 'Gem Keeper' }
  ];

  const handleStart = () => {
    if (userName.trim()) {
      dispatch({ 
        type: 'SET_USER_INFO', 
        payload: { userName: userName.trim(), userAvatar: selectedAvatar } 
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-20 w-1 h-1 bg-blue-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-32 left-1/4 w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse"></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-green-400 rounded-full animate-ping"></div>
      </div>

      <div className="max-w-md mx-auto relative z-10">
        <div className="bg-slate-800/90 backdrop-blur-md rounded-3xl p-8 shadow-2xl border border-slate-700/50">
          {/* Epic Header */}
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-amber-400 via-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg animate-pulse">
              <Sword className="h-12 w-12 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent mb-2">
              Inclusion Quest
            </h1>
            <p className="text-slate-300 text-lg font-medium">
              ⚔️ Epic GBA+ Adventure ⚔️
            </p>
            <p className="text-slate-400 text-sm mt-2">
              Embark on a legendary journey to master workplace inclusion
            </p>
          </div>

          {/* Quest Stats */}
          <div className="grid grid-cols-3 gap-3 mb-8">
            <div className="text-center p-3 bg-emerald-900/30 rounded-xl border border-emerald-700/30">
              <Clock className="h-5 w-5 text-emerald-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-emerald-300">15 min</div>
              <div className="text-xs text-emerald-500">Quest Time</div>
            </div>
            <div className="text-center p-3 bg-blue-900/30 rounded-xl border border-blue-700/30">
              <Zap className="h-5 w-5 text-blue-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-blue-300">4 Realms</div>
              <div className="text-xs text-blue-500">To Conquer</div>
            </div>
            <div className="text-center p-3 bg-purple-900/30 rounded-xl border border-purple-700/30">
              <Trophy className="h-5 w-5 text-purple-400 mx-auto mb-1" />
              <div className="text-xs font-bold text-purple-300">Epic Loot</div>
              <div className="text-xs text-purple-500">Awaits</div>
            </div>
          </div>

          {/* Character Creation */}
          <div className="mb-6">
            <h3 className="text-white font-bold mb-3 flex items-center">
              <Shield className="h-5 w-5 mr-2 text-amber-400" />
              Choose Your Avatar
            </h3>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {avatarOptions.map((avatar) => (
                <button
                  key={avatar.emoji}
                  onClick={() => setSelectedAvatar(avatar.emoji)}
                  className={`text-2xl p-3 rounded-xl transition-all duration-300 border-2 ${
                    selectedAvatar === avatar.emoji 
                      ? 'bg-amber-500/20 border-amber-400 scale-110 shadow-lg' 
                      : 'bg-slate-700/50 border-slate-600 hover:bg-slate-600/50 hover:border-slate-500'
                  }`}
                  title={avatar.name}
                >
                  {avatar.emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Hero Name */}
          <div className="mb-8">
            <label className="block text-sm font-bold text-slate-300 mb-2 flex items-center">
              <Star className="h-4 w-4 mr-2 text-amber-400" />
              Hero Name
            </label>
            <input
              type="text"
              placeholder="Enter your hero name..."
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-700/50 border-2 border-slate-600 text-white placeholder-slate-400 focus:border-amber-400 focus:outline-none transition-all duration-300 focus:shadow-lg focus:shadow-amber-400/20"
              onKeyPress={(e) => e.key === 'Enter' && handleStart()}
            />
          </div>

          {/* Epic Start Button */}
          <button
            onClick={handleStart}
            disabled={!userName.trim()}
            className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 hover:from-amber-600 hover:via-orange-600 hover:to-red-600 disabled:from-slate-600 disabled:to-slate-700 text-white py-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed flex items-center justify-center shadow-xl disabled:shadow-none relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 translate-x-[-100%] hover:translate-x-[100%] transition-transform duration-1000"></div>
            <Play className="mr-2 h-5 w-5" />
            Begin Epic Quest
          </button>

          {/* Quest Preview */}
          <div className="mt-6 p-4 bg-slate-700/30 rounded-xl border border-slate-600/30">
            <p className="text-xs text-slate-300 text-center leading-relaxed">
              🏰 <strong>Your Quest:</strong> Navigate the four mystical realms of workplace inclusion, 
              make wise choices, and emerge as a true GBA+ champion! ⚔️✨
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;