import React from 'react';
import { useGame, Character } from '../contexts/GameContext';
import { ArrowRight, User, Brain, MessageSquare, Sparkles } from 'lucide-react';

const characters: Character[] = [
  {
    id: 'yourself',
    name: 'The True Hero',
    avatar: '👤',
    description: 'Embark as yourself - the most powerful path to mastery'
  },
  {
    id: 'problem-solver',
    name: 'The Sage Strategist',
    avatar: '🧙‍♂️',
    description: 'A wise tactician who solves challenges with ancient wisdom'
  },
  {
    id: 'communicator',
    name: 'The Harmony Keeper',
    avatar: '🕊️',
    description: 'A diplomatic soul who unites all beings in understanding'
  }
];

const CharacterSelection: React.FC = () => {
  const { state, dispatch } = useGame();

  const selectCharacter = (character: Character) => {
    const finalCharacter = character.id === 'yourself' 
      ? { ...character, avatar: state.userAvatar, name: state.userName }
      : character;
    
    dispatch({ type: 'SELECT_CHARACTER', payload: finalCharacter });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Mystical Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      <div className="max-w-2xl mx-auto relative z-10">
        <div className="bg-slate-800/90 backdrop-blur-md rounded-3xl p-8 shadow-2xl border border-slate-700/50">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mb-2">
              Choose Your Path
            </h2>
            <p className="text-slate-300">
              Select your character class for this legendary quest
            </p>
          </div>

          <div className="space-y-4">
            {characters.map((character, index) => (
              <button
                key={character.id}
                onClick={() => selectCharacter(character)}
                className={`w-full p-6 rounded-2xl border-2 transition-all duration-300 hover:scale-[1.02] relative overflow-hidden ${
                  character.id === 'yourself' 
                    ? 'border-amber-400 bg-gradient-to-r from-amber-900/30 to-orange-900/30 shadow-lg shadow-amber-500/20' 
                    : 'border-slate-600 bg-slate-700/30 hover:border-slate-500 hover:bg-slate-600/30'
                }`}
              >
                {character.id === 'yourself' && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-400/10 to-transparent transform -skew-x-12 translate-x-[-100%] hover:translate-x-[100%] transition-transform duration-1000"></div>
                )}
                
                <div className="flex items-center relative z-10">
                  <div className="text-5xl mr-6">
                    {character.id === 'yourself' ? state.userAvatar : character.avatar}
                  </div>
                  <div className="flex-1 text-left">
                    <div className="flex items-center mb-2">
                      {character.id === 'yourself' && <User className="h-5 w-5 mr-2 text-amber-400" />}
                      <h3 className="font-bold text-white text-xl">
                        {character.id === 'yourself' ? state.userName : character.name}
                      </h3>
                      {character.id === 'yourself' && (
                        <span className="ml-3 px-3 py-1 bg-amber-500/20 text-amber-300 text-xs font-bold rounded-full border border-amber-400/30">
                          ⭐ LEGENDARY
                        </span>
                      )}
                    </div>
                    <p className="text-slate-300 text-sm">{character.description}</p>
                  </div>
                  <ArrowRight className="h-6 w-6 text-slate-400" />
                </div>
              </button>
            ))}
          </div>

          <div className="mt-8 p-6 bg-gradient-to-r from-blue-900/30 to-purple-900/30 rounded-2xl border border-blue-700/30">
            <div className="flex items-start">
              <div className="text-2xl mr-3">💡</div>
              <div>
                <h3 className="text-blue-300 font-bold mb-2">Hero's Wisdom</h3>
                <p className="text-slate-300 text-sm leading-relaxed">
                  Choosing "The True Hero" (yourself) unlocks the most powerful learning magic. 
                  When you see yourself making these choices, the lessons become part of your very essence!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterSelection;