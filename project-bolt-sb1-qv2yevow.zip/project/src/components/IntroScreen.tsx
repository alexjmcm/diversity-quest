import React from 'react';
import { useGame } from '../contexts/GameContext';
import { ArrowRight, Briefcase, Users, Lightbulb } from 'lucide-react';

const IntroScreen: React.FC = () => {
  const { state, dispatch } = useGame();

  const handleStartScenario = () => {
    dispatch({ type: 'START_SCENARIO' });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">{state.selectedCharacter?.avatar}</div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
              The Team Project Dilemma
            </h1>
            <p className="text-lg text-gray-200 max-w-2xl mx-auto">
              You're about to embark on a new team project. Your decisions will shape the team dynamics and project outcomes.
            </p>
          </div>

          <div className="bg-white/5 rounded-xl p-6 mb-8">
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
              <Briefcase className="h-6 w-6 mr-3 text-purple-400" />
              Scenario Setup
            </h2>
            <p className="text-gray-200 leading-relaxed mb-4">
              Your organization has just launched a new initiative to develop a customer service improvement strategy. 
              You've been assigned to a diverse, cross-functional team of six people from different departments, 
              backgrounds, and experience levels.
            </p>
            <p className="text-gray-200 leading-relaxed">
              As the project unfolds, you'll encounter various situations that require you to apply GBA+ principles 
              and inclusive practices. Your choices will demonstrate how Gender-Based Analysis Plus can create 
              better outcomes for everyone involved.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white/5 rounded-xl p-6 border border-white/10">
              <Users className="h-8 w-8 text-blue-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-2 text-center">Team Formation</h3>
              <p className="text-gray-300 text-sm text-center">How will you ensure diverse voices are heard?</p>
            </div>
            <div className="bg-white/5 rounded-xl p-6 border border-white/10">
              <Lightbulb className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-2 text-center">Problem-Solving</h3>
              <p className="text-gray-300 text-sm text-center">Navigate conflicts with inclusive approaches</p>
            </div>
            <div className="bg-white/5 rounded-xl p-6 border border-white/10">
              <Briefcase className="h-8 w-8 text-green-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-2 text-center">Recognition</h3>
              <p className="text-gray-300 text-sm text-center">Provide feedback that values all contributions</p>
            </div>
          </div>

          <div className="bg-purple-500/10 border border-purple-400/30 rounded-xl p-6 mb-8">
            <h3 className="text-purple-300 font-semibold mb-2">What is GBA+?</h3>
            <p className="text-gray-200 text-sm">
              Gender-Based Analysis Plus (GBA+) is an analytical tool that helps us understand how diverse groups 
              of people may experience policies, programs, and initiatives differently. The "plus" acknowledges 
              that gender intersects with many other identity factors like age, culture, disability, and more.
            </p>
          </div>

          <div className="text-center">
            <button
              onClick={handleStartScenario}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 flex items-center mx-auto"
            >
              Start the Project
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IntroScreen;